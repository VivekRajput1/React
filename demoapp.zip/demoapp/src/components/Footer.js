import React from 'react';
import './layout.css'
export function Footer(){
    return (
        <div className="footer">
            <h2>Footer</h2>
        </div>
    );
}