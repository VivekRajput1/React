import React from 'react';
import './layout.css'
export function Header(){
    
    return (
        <div className="header">
  <h1>Demo App</h1>
</div>
    );
}