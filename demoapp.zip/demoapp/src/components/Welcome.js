import React, { Component } from 'react';

class Welcome extends Component {
    render() {
        return (
            <div className="welcome">
                <h1>Welcome in React..</h1>
            </div>
        );
    }
}

export default Welcome;