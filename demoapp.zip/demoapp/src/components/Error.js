import React, { Component } from 'react';


class Error extends Component {
    render() {
        return (
            <div className="welcome">
                <h1>This is error page</h1>
            </div>
        );
    }
}
export default Error;